# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Rater', '0008_auto_20150615_1916'),
    ]

    operations = [
        migrations.RemoveField(
            model_name='rating',
            name='dt',
        ),
        migrations.AddField(
            model_name='rating',
            name='posted',
            field=models.DateTimeField(default=978302109),
        ),
    ]
