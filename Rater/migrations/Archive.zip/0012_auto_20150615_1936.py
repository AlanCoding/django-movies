# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('Rater', '0011_auto_20150615_1922'),
    ]

    operations = [
        migrations.AlterField(
            model_name='rating',
            name='posted',
            field=models.DateTimeField(default=datetime.datetime(2000, 7, 14, 12, 30)),
        ),
    ]
