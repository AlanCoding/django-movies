# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('Rater', '0010_auto_20150615_1921'),
    ]

    operations = [
        migrations.AlterField(
            model_name='rating',
            name='posted',
            field=models.DateTimeField(default=datetime.datetime(2000, 12, 31, 22, 35, 9)),
        ),
    ]
