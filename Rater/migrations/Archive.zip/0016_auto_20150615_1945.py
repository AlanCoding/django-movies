# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('Rater', '0015_auto_20150615_1942'),
    ]

    operations = [
        migrations.AlterField(
            model_name='rating',
            name='posted',
            field=models.IntegerField(default=0),
        ),
    ]
