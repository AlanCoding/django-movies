# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
import datetime


class Migration(migrations.Migration):

    dependencies = [
        ('Rater', '0006_auto_20150615_1912'),
    ]

    operations = [
        migrations.AlterField(
            model_name='rating',
            name='dt',
            field=models.DateTimeField(default=datetime.datetime.now),
        ),
    ]
